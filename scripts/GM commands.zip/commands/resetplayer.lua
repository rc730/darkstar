---------------------------------------------------------------------------------------------------
-- Deprecated
---------------------------------------------------------------------------------------------------

cmdprops =
{
    permission = 1,
    parameters = ""
};

function onTrigger(player)
    player:PrintToPlayer("Deprecated. Use @posfix instead.");
end
